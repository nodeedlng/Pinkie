/* Only show the sections necessary */

var postcontainers = document.getElementsByClassName("postcontainer");

for (var i = 0; i < postcontainers.length; i++) {
    postcontainers[i].style.display = "none";
}